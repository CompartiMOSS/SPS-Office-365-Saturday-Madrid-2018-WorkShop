﻿namespace SPS.Graph.HOL.ViewModels
{
    public class ContactsModel
    {
        public string ContactInfo { get; set; }
    }
}
